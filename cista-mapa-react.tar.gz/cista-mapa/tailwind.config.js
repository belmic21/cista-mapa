/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#0f1115',
        panel: '#171a21',
        panel2: '#1d212a',
        line: '#2a2f3a',
        line2: '#363c49',
        ink: '#e7e9ee',
        dim: '#9aa1ad',
        faint: '#6b7280',
        have: '#1f9d57',
        partial: '#e0922b',
        empty: '#5b6470',
        vote: '#3da5ff',
        hlas: '#2fbf71',
      },
    },
  },
  plugins: [],
}
