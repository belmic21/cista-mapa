import { useEffect, useState } from 'react'
import { supabase } from './lib/supabase'
import { useStore } from './lib/store'
import Login from './components/Login'
import Shell from './components/Shell'

export default function App() {
  const { user, setUser, setProfil, loading } = useStore()
  const [checking, setChecking] = useState(true)

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) {
        setUser(data.session.user)
        loadProfil(data.session.user.id)
      }
      setChecking(false)
    })
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session) {
        setUser(session.user)
        loadProfil(session.user.id)
      } else {
        setUser(null)
        setProfil(null)
      }
    })
    return () => subscription.unsubscribe()
  }, [])

  async function loadProfil(userId) {
    const { data } = await supabase.from('profily').select('*').eq('id', userId).single()
    if (data) setProfil(data)
    else setProfil({ id: userId, role: 'servis', jmeno: '' }) // default servis
  }

  if (checking) return (
    <div className="h-screen flex items-center justify-center bg-bg">
      <div className="text-dim">Načítám…</div>
    </div>
  )

  if (!user) return <Login />

  return <Shell />
}
