import { useEffect, useRef, useState } from 'react'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { useStore, jeVolic, maKontakt, vek } from '../lib/store'
import { CISTA_CENTER, CISTA_ZOOM } from '../lib/supabase'

export default function MapView() {
  const mapRef = useRef(null)
  const mapInst = useRef(null)
  const layersRef = useRef({})
  const gpsRef = useRef({ watch: null, marker: null, circle: null })
  const [gpsOn, setGpsOn] = useState(false)

  const {
    domy, osoby, context, stitky, skupiny, colorMode,
    searchQuery, searchFields, searchExact, filters,
    selectedId, select, paintMode, paintTarget, saveDum,
    ageMin, ageMax, isAdmin,
  } = useStore()

  // Init map
  useEffect(() => {
    if (mapInst.current) return
    const map = L.map(mapRef.current, { zoomControl: true, attributionControl: false })
      .setView(CISTA_CENTER, CISTA_ZOOM)

    const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 })
    const ortho = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19 })
    osm.addTo(map)
    L.control.layers({ 'Mapa': osm, 'Fotomapa': ortho }, null, { position: 'topright' }).addTo(map)

    layersRef.current = {
      ctx: L.layerGroup().addTo(map),
      houses: L.layerGroup().addTo(map),
      labels: L.layerGroup().addTo(map),
      highlight: L.layerGroup().addTo(map),
    }
    mapInst.current = map

    map.on('click', (e) => {
      const store = useStore.getState()
      if (store.paintMode) return // handled in house click
    })

    return () => { map.remove(); mapInst.current = null }
  }, [])

  // Render houses
  useEffect(() => {
    if (!mapInst.current) return
    const { ctx, houses, labels, highlight } = layersRef.current
    const map = mapInst.current

    ctx.clearLayers()
    houses.clearLayers()
    labels.clearLayers()
    highlight.clearLayers()

    // Context buildings
    context.forEach(coords => {
      L.polygon(coords, { color: '#3a4150', weight: 1, fillColor: '#222831', fillOpacity: .35, interactive: false }).addTo(ctx)
    })

    const store = useStore.getState()
    const fActive = isFilterActive(store)

    // Sort: matching on top
    const sorted = [...domy].sort((a, b) => {
      const ma = fActive ? passFilter(a, store) : true
      const mb = fActive ? passFilter(b, store) : true
      return ma === mb ? 0 : (ma ? 1 : -1)
    })

    sorted.forEach(d => {
      if (!d.lat) return
      const match = passFilter(d, store)
      const muted = fActive && !match
      const hot = fActive && match
      const col = houseColor(d, store)
      const sel = d.id === selectedId

      let edge = sel ? '#fff' : '#0b0d10'
      let w = sel ? 2.6 : 1.4
      let polyFill = .62, fillOp = 1, r = d.poly ? 4.5 : 7

      if (muted) { edge = '#0b0d10'; w = .8; polyFill = .05; fillOp = .12; r = d.poly ? 2.5 : 3.5 }
      else if (hot) { edge = '#fff'; w = 2.8; polyFill = .85; fillOp = 1; r = d.poly ? 8 : 12 }

      if (d.poly) {
        const pg = L.polygon(d.poly, { color: edge, weight: w, fillColor: col, fillOpacity: polyFill }).addTo(houses)
        pg.on('click', ev => { L.DomEvent.stop(ev); handleClick(d) })
        pg.bindTooltip(tipHtml(d, store), { direction: 'top', opacity: .97 })
      }

      if (hot) {
        L.circleMarker([d.lat, d.lon], { radius: r + 8, stroke: false, fillColor: col, fillOpacity: .28, interactive: false }).addTo(houses)
        L.circleMarker([d.lat, d.lon], { radius: r + 3, color: '#fff', weight: 1.5, opacity: .9, fill: false, interactive: false }).addTo(houses)
      }

      const mk = L.circleMarker([d.lat, d.lon], { radius: r, color: edge, weight: w, fillColor: col, fillOpacity: fillOp }).addTo(houses)
      mk.on('click', ev => { L.DomEvent.stop(ev); handleClick(d) })
      if (!d.poly) mk.bindTooltip(tipHtml(d, store), { direction: 'top', opacity: .97 })

      // Labels at zoom
      if (map.getZoom() >= (fActive ? 15 : 17) && d.cp && !muted) {
        L.marker([d.lat, d.lon], {
          interactive: false,
          icon: L.divIcon({ html: `<div class="lbl">${esc(d.cp)}</div>`, iconSize: [1, 1] })
        }).addTo(labels)
      }
    })
  }, [domy, osoby, context, colorMode, searchQuery, searchFields, searchExact, filters, selectedId, paintMode, paintTarget, stitky, skupiny, ageMin, ageMax])

  function handleClick(d) {
    const store = useStore.getState()
    if (store.paintMode) {
      const updated = { ...d }
      if (store.paintTarget === 'erase' || d.stitekId === store.paintTarget) updated.stitekId = ''
      else updated.stitekId = store.paintTarget
      useStore.setState(s => ({ domy: s.domy.map(x => x.id === d.id ? updated : x), colorMode: 'stitek' }))
      store.saveDum(updated)
    } else {
      select(d.id, 'dum')
    }
  }

  // GPS
  function toggleGps() {
    if (gpsOn) {
      if (gpsRef.current.watch) navigator.geolocation.clearWatch(gpsRef.current.watch)
      if (gpsRef.current.marker) { mapInst.current.removeLayer(gpsRef.current.marker); mapInst.current.removeLayer(gpsRef.current.circle) }
      gpsRef.current = { watch: null, marker: null, circle: null }
      setGpsOn(false)
      return
    }
    if (!navigator.geolocation) return alert('GPS není k dispozici.')
    setGpsOn(true)
    gpsRef.current.watch = navigator.geolocation.watchPosition(pos => {
      const ll = [pos.coords.latitude, pos.coords.longitude]
      const acc = pos.coords.accuracy
      if (!gpsRef.current.marker) {
        gpsRef.current.marker = L.circleMarker(ll, { radius: 7, color: '#fff', weight: 2, fillColor: '#3b82f6', fillOpacity: 1 }).addTo(mapInst.current)
        gpsRef.current.circle = L.circle(ll, { radius: acc, color: '#3b82f680', weight: 1, fillColor: '#3b82f6', fillOpacity: .1, interactive: false }).addTo(mapInst.current)
        mapInst.current.setView(ll, 17)
      } else {
        gpsRef.current.marker.setLatLng(ll)
        gpsRef.current.circle.setLatLng(ll).setRadius(acc)
      }
    }, err => alert('GPS: ' + err.message), { enableHighAccuracy: true, maximumAge: 5000 })
  }

  return (
    <div className="absolute inset-0">
      <div ref={mapRef} className="w-full h-full" />
      <button onClick={toggleGps}
        className={`absolute bottom-4 right-4 z-[500] px-3 py-2.5 rounded-xl shadow-lg border text-sm font-semibold
          ${gpsOn ? 'bg-ink text-bg border-ink' : 'bg-panel border-line2 text-ink'}`}>
        📍 {gpsOn ? 'GPS zapnuto' : 'Moje poloha'}
      </button>
    </div>
  )
}

// ---------- helpers ----------

const esc = s => (s == null ? '' : String(s)).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]))

function houseColor(d, store) {
  const { colorMode, stitky, skupiny, osoby } = store
  const akt = osoby.filter(o => o.domId === d.id && o.aktivni !== false)
  if (colorMode === 'stitek') { const s = stitky.find(x => x.id === d.stitekId); return s ? s.color : '#39414f' }
  if (colorMode === 'skupina') { for (const o of akt) { const s = skupiny.find(x => x.id === o.skupinaId); if (s) return s.color } return '#39414f' }
  if (colorMode === 'stav') { if (akt.some(maKontakt)) return '#1f9d57'; if (akt.length) return '#e0922b'; return '#5b6470' }
  if (colorMode === 'hlas') { if (akt.some(o => jeVolic(o) && o.hlas)) return '#2fbf71'; if (akt.some(jeVolic)) return '#e0922b'; return '#5b6470' }
  if (colorMode === 'volic') { return akt.some(jeVolic) ? '#3da5ff' : '#5b6470' }
  return '#5b6470'
}

function isFilterActive(store) {
  const { filters, searchQuery, ageMin, ageMax } = store
  return filters.voters || filters.hlas || filters.soon || filters.gaps || !!filters.stFilter || !!filters.skFilter || !!searchQuery.trim() || ageMin != null || ageMax != null
}

function passFilter(d, store) {
  const { osoby, filters, searchQuery, searchFields, searchExact, ageMin, ageMax, skupiny } = store
  const akt = osoby.filter(o => o.domId === d.id && o.aktivni !== false)

  if (filters.gaps && akt.some(maKontakt)) return false
  if (filters.gaps && !akt.length) return true // no people = gap
  if (filters.voters && !akt.some(jeVolic)) return false
  if (filters.hlas && !akt.some(o => jeVolic(o) && o.hlas)) return false
  if (filters.soon && !akt.some(o => { const v = vek(o.rok); return !!o.pobyt && v != null && v >= 15 && v < 18 })) return false
  if (filters.stFilter && d.stitekId !== filters.stFilter) return false
  if (filters.skFilter && !akt.some(o => o.skupinaId === filters.skFilter)) return false

  if (ageMin != null || ageMax != null) {
    if (!akt.some(o => { const v = vek(o.rok); if (v == null) return false; if (ageMin != null && v < ageMin) return false; if (ageMax != null && v > ageMax) return false; return true })) return false
  }

  const q = searchQuery.trim()
  if (q) {
    const tokens = q.toLowerCase().split(/\s+/).filter(Boolean)
    const hayParts = []
    if (searchFields.cp) hayParts.push(d.cp)
    if (searchFields.parcela) hayParts.push(d.parcela)
    if (searchFields.pozn) hayParts.push(d.pozn)
    akt.forEach(o => {
      if (searchFields.jmena) hayParts.push(o.jmeno, o.rok)
      if (searchFields.tel) hayParts.push(o.tel)
      if (searchFields.email) hayParts.push(o.email)
    })
    const hay = hayParts.join(' ').toLowerCase()
    if (searchExact) {
      if (!tokens.every(t => hay.split(/\s+/).some(w => w === t))) return false
    } else {
      if (!tokens.every(t => hay.includes(t))) return false
    }
  }

  return true
}

function tipHtml(d, store) {
  const akt = store.osoby.filter(o => o.domId === d.id && o.aktivni !== false)
    .sort((a, b) => (a.jmeno || '\uffff').localeCompare(b.jmeno || '\uffff', 'cs'))
  const hist = store.osoby.filter(o => o.domId === d.id && o.aktivni === false).length
  const hlasy = akt.filter(o => jeVolic(o) && o.hlas).length
  const names = akt.slice(0, 14).map(o => {
    const v = vek(o.rok)
    return esc(o.jmeno || '(bez jména)') + (o.jednotka ? ' [' + esc(o.jednotka) + ']' : '') + (v != null ? ' (' + v + ')' : '')
  }).join('<br>')
  const more = akt.length > 14 ? '<br>…+' + (akt.length - 14) : ''
  return `<div class="tt"><b>č.p. ${esc(d.cp || '—')}</b>${d.parcela ? ' · parc. ' + esc(d.parcela) : ''}
    <div class="nm">${akt.length} osob · ${akt.filter(jeVolic).length} voličů${hlasy ? ' · ' + hlasy + ' hlasů' : ''}${hist ? ' · ' + hist + ' hist.' : ''}</div>
    ${akt.length ? '<div class="nm">' + names + more + '</div>' : ''}</div>`
}
