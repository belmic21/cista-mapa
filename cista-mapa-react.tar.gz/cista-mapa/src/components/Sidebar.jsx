import { useState } from 'react'
import { useStore, jeVolic, jeBudouci, vek, maKontakt } from '../lib/store'

export default function Sidebar({ status, onClose }) {
  const store = useStore()
  const { domy, osoby, stitky, skupiny, znacky, vrstvy, meta, isAdmin,
    colorMode, filters, paintMode, paintTarget, ageMin, ageMax } = store
  const stats = store.stats()

  return (
    <div className="text-sm">
      {/* Stats */}
      <Section title="Souhrn">
        <div className="grid grid-cols-3 gap-1.5">
          <Kpi v={stats.domu} l="Domů" />
          <Kpi v={stats.osob} l="Osob" />
          <Kpi v={stats.volicu} l="Voličů" />
          <Kpi v={stats.hlasu} l="Slíb. hlasů" />
          <Kpi v={stats.budoucich} l="Budoucích" />
          <Kpi v={stats.prumerVek ?? '–'} l="Ø věk" />
        </div>
        <div className="text-xs text-dim mt-2.5">
          Domů s kontaktem: <b className="text-ink">{stats.domuKontakt}</b> · osob s kontaktem: <b className="text-ink">{stats.osobKontakt}</b>
        </div>
        <Bar label="Domácnosti oslovené" pct={stats.domu ? Math.round(stats.domuKontakt / stats.domu * 100) : 0} color="bg-have" />
        <Bar label="Slíbené hlasy" pct={stats.volicu ? Math.round(stats.hlasu / stats.volicu * 100) : 0} sub={`${stats.hlasu} z ${stats.volicu}`} color="bg-hlas" />
      </Section>

      {/* Color mode */}
      <Section title="Obarvení mapy">
        <select value={colorMode} onChange={e => useStore.setState({ colorMode: e.target.value })}
          className="w-full px-2 py-1.5 bg-panel2 border border-line2 rounded-md text-ink text-sm">
          <option value="stitek">Štítky domů</option>
          <option value="skupina">Skupiny lidí</option>
          <option value="stav">Stav kontaktu</option>
          <option value="hlas">Příslib hlasu</option>
          <option value="volic">Voliči v domě</option>
        </select>
      </Section>

      {/* Paint */}
      {isAdmin() && (
        <Section title="Malování domů">
          <button onClick={() => useStore.setState(s => ({ paintMode: !s.paintMode, paintTarget: s.paintMode ? null : (stitky[0]?.id || 'erase') }))}
            className={`w-full px-3 py-2 rounded-md border text-sm ${paintMode ? 'bg-ink text-bg border-ink' : 'border-line2 text-ink'}`}>
            🖌 {paintMode ? 'Vypnout' : 'Zapnout malování'}
          </button>
          {paintMode && (
            <div className="flex flex-wrap gap-2 mt-2">
              {stitky.map(s => (
                <button key={s.id} onClick={() => useStore.setState({ paintTarget: s.id })}
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-full border text-xs ${paintTarget === s.id ? 'border-ink bg-panel2' : 'border-line2'}`}>
                  <span className="w-3 h-3 rounded-full border border-black/30" style={{ background: s.color }} />
                  {s.name}
                </button>
              ))}
              <button onClick={() => useStore.setState({ paintTarget: 'erase' })}
                className={`px-2.5 py-1.5 rounded-full border text-xs ${paintTarget === 'erase' ? 'border-ink bg-panel2' : 'border-line2'}`}>
                guma
              </button>
            </div>
          )}
        </Section>
      )}

      {/* Filters */}
      <Section title="Filtr">
        <Check label="Jen domy s voliči" checked={filters.voters} onChange={v => store.setFilter('voters', v)} />
        <Check label="Jen se slíbeným hlasem" checked={filters.hlas} onChange={v => store.setFilter('hlas', v)} />
        <Check label="Jen s budoucím voličem" checked={filters.soon} onChange={v => store.setFilter('soon', v)} />
        <Check label="Jen bez kontaktu (mezery)" checked={filters.gaps} onChange={v => store.setFilter('gaps', v)} />
        <div className="mt-2.5">
          <div className="text-[10px] text-faint uppercase tracking-wider mb-1">Vysvítit štítek:</div>
          <select value={filters.stFilter} onChange={e => store.setFilter('stFilter', e.target.value)}
            className="w-full px-2 py-1.5 bg-panel2 border border-line2 rounded-md text-xs">
            <option value="">— vše —</option>
            {stitky.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </div>
        <div className="mt-2">
          <div className="text-[10px] text-faint uppercase tracking-wider mb-1">Vysvítit skupinu:</div>
          <select value={filters.skFilter} onChange={e => store.setFilter('skFilter', e.target.value)}
            className="w-full px-2 py-1.5 bg-panel2 border border-line2 rounded-md text-xs">
            <option value="">— vše —</option>
            {skupiny.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </div>
      </Section>

      {/* Age range */}
      <Section title="Věkové rozmezí">
        <div className="flex items-center gap-2">
          <input type="number" inputMode="numeric" placeholder="od" value={ageMin ?? ''}
            onChange={e => useStore.setState({ ageMin: e.target.value ? +e.target.value : null })}
            className="w-16 px-2 py-1.5 bg-panel2 border border-line2 rounded-md text-xs tabular-nums" />
          <span className="text-faint">–</span>
          <input type="number" inputMode="numeric" placeholder="do" value={ageMax ?? ''}
            onChange={e => useStore.setState({ ageMax: e.target.value ? +e.target.value : null })}
            className="w-16 px-2 py-1.5 bg-panel2 border border-line2 rounded-md text-xs tabular-nums" />
          <button onClick={() => useStore.setState({ ageMin: null, ageMax: null })}
            className="ml-auto text-dim text-xs px-2 py-1 border border-line2 rounded-md">×</button>
        </div>
        <div className="flex flex-wrap gap-1.5 mt-2">
          {[['0–17', 0, 17], ['15–17', 15, 17], ['18–64', 18, 64], ['65+', 65, null]].map(([l, lo, hi]) => (
            <button key={l} onClick={() => useStore.setState({ ageMin: lo, ageMax: hi })}
              className="px-2 py-1 border border-line2 rounded-full text-xs text-dim">{l}</button>
          ))}
        </div>
      </Section>

      {/* Štítky */}
      {isAdmin() && <TagSection title="Štítky domů" items={stitky} type="stitek" />}
      {isAdmin() && <TagSection title="Skupiny lidí" items={skupiny} type="skupina" />}

      {/* Layers */}
      <Section title="Vrstvy">
        {vrstvy.length ? vrstvy.map(v => (
          <div key={v.id} className="flex items-center gap-2 py-1">
            <span className="w-3 h-3 rounded-sm border border-black/30" style={{ background: v.barva }} />
            <span className="flex-1 text-xs">{v.nazev}</span>
            <span className="text-[10px] text-faint">{v.typ}</span>
          </div>
        )) : <div className="text-xs text-faint">Zatím žádné vrstvy.</div>}
        {isAdmin() && (
          <button className="w-full mt-2 px-3 py-1.5 border border-line2 rounded-md text-xs text-dim">
            + Nová vrstva
          </button>
        )}
      </Section>

      {/* Status */}
      <Section title="">
        <div className={`text-[11px] ${status === 'Online' ? 'text-have' : 'text-faint'}`}>
          {status === 'Online' ? '● Online · Supabase' : status}
        </div>
      </Section>
    </div>
  )
}

// Sub-components
function Section({ title, children }) {
  return (
    <div className="border-b border-line px-3.5 py-3">
      {title && <h3 className="text-[11px] uppercase tracking-widest text-dim font-semibold mb-2.5">{title}</h3>}
      {children}
    </div>
  )
}

function Kpi({ v, l }) {
  return (
    <div className="bg-panel2 border border-line rounded-lg px-2 py-1.5">
      <div className="text-lg font-bold leading-none tabular-nums">{v}</div>
      <div className="text-[10px] text-dim mt-1">{l}</div>
    </div>
  )
}

function Bar({ label, pct, sub, color }) {
  return (
    <div className="mt-2.5">
      <div className="flex justify-between text-xs text-dim mb-1"><span>{label}</span><span>{sub || `${pct} %`}</span></div>
      <div className="h-2 rounded-full bg-panel2 border border-line overflow-hidden">
        <div className={`h-full ${color} rounded-full`} style={{ width: `${Math.min(100, pct)}%` }} />
      </div>
    </div>
  )
}

function Check({ label, checked, onChange }) {
  return (
    <label className="flex items-center gap-2 py-1 cursor-pointer text-xs">
      <input type="checkbox" checked={checked} onChange={e => onChange(e.target.checked)}
        className="w-4 h-4 accent-gray-400" />
      {label}
    </label>
  )
}

function TagSection({ title, items, type }) {
  const [name, setName] = useState('')
  const [color, setColor] = useState(type === 'stitek' ? '#3da5ff' : '#2fbf71')
  const store = useStore()

  async function add() {
    if (!name.trim()) return
    const item = { id: crypto.randomUUID(), name: name.trim(), color }
    if (type === 'stitek') {
      useStore.setState(s => ({ stitky: [...s.stitky, item] }))
      await store.saveStitek(item)
    } else {
      useStore.setState(s => ({ skupiny: [...s.skupiny, item] }))
      await store.saveSkupina(item)
    }
    setName('')
  }

  return (
    <Section title={title}>
      {items.map(s => (
        <div key={s.id} className="flex items-center gap-2 py-0.5">
          <span className="w-3.5 h-3.5 rounded-sm border border-black/30" style={{ background: s.color }} />
          <span className="flex-1 text-xs">{s.name}</span>
          {type === 'skupina' && (
            <span className="text-[10px] text-faint">
              {store.osoby.filter(o => o.skupinaId === s.id).length}
            </span>
          )}
        </div>
      ))}
      <div className="flex gap-1.5 mt-2">
        <input value={name} onChange={e => setName(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && add()}
          placeholder="Název" className="flex-1 min-w-0 px-2 py-1 bg-panel2 border border-line2 rounded-md text-xs" />
        <input type="color" value={color} onChange={e => setColor(e.target.value)}
          className="w-8 h-7 p-0 border border-line2 rounded-md cursor-pointer" />
        <button onClick={add} className="px-2 py-1 border border-line2 rounded-md text-xs">+</button>
      </div>
    </Section>
  )
}
