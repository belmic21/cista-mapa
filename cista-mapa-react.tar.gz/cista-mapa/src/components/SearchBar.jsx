import { useState } from 'react'
import { useStore } from '../lib/store'

const FIELDS = [
  { key: 'cp', label: 'č.p.' },
  { key: 'jmena', label: 'Jména' },
  { key: 'tel', label: 'Telefon' },
  { key: 'email', label: 'E-mail' },
  { key: 'parcela', label: 'Parcela' },
  { key: 'pozn', label: 'Poznámka' },
]

export default function SearchBar() {
  const { searchQuery, setSearchQuery, searchFields, setSearchField, searchExact, setSearchExact } = useStore()
  const [open, setOpen] = useState(false)

  return (
    <div className="flex-1 relative min-w-0">
      <div className="flex items-center gap-1">
        <input
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          placeholder="Hledat…"
          className="flex-1 min-w-0 px-3 py-1.5 bg-panel2 border border-line2 rounded-lg text-ink text-sm"
        />
        <button
          onClick={() => setOpen(!open)}
          className={`px-2 py-1.5 text-xs border rounded-lg ${open ? 'bg-ink text-bg border-ink' : 'bg-panel2 border-line2 text-dim'}`}
        >
          ⚙
        </button>
      </div>

      {open && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-panel border border-line rounded-lg p-3 shadow-2xl z-50">
          <div className="text-[11px] text-faint uppercase tracking-wider mb-2">Hledat v polích:</div>
          <div className="flex flex-wrap gap-3 mb-3">
            {FIELDS.map(f => (
              <label key={f.key} className="flex items-center gap-1.5 text-xs text-dim cursor-pointer">
                <input type="checkbox" checked={searchFields[f.key]}
                  onChange={e => setSearchField(f.key, e.target.checked)}
                  className="w-3.5 h-3.5 accent-gray-400" />
                {f.label}
              </label>
            ))}
          </div>
          <div className="flex items-center gap-3 text-xs">
            <label className={`flex items-center gap-1.5 cursor-pointer px-2.5 py-1 rounded-full border ${!searchExact ? 'bg-ink text-bg border-ink' : 'border-line2 text-dim'}`}>
              <input type="radio" name="mode" checked={!searchExact} onChange={() => setSearchExact(false)} className="hidden" />
              Obsahuje
            </label>
            <label className={`flex items-center gap-1.5 cursor-pointer px-2.5 py-1 rounded-full border ${searchExact ? 'bg-ink text-bg border-ink' : 'border-line2 text-dim'}`}>
              <input type="radio" name="mode" checked={searchExact} onChange={() => setSearchExact(true)} className="hidden" />
              Přesně
            </label>
          </div>
        </div>
      )}
    </div>
  )
}
