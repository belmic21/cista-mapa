import { useState, useRef, useEffect } from 'react'
import { useStore, jeVolic, jeBudouci, vek, maKontakt } from '../lib/store'

export default function Editor() {
  const { selectedId, editorKind, domy, osoby, stitky, skupiny, closeEditor, isAdmin,
    saveDum, saveOsoba, deleteOsoba, deleteDum } = useStore()

  const d = domy.find(x => x.id === selectedId)
  if (!d) return null

  const akt = osoby.filter(o => o.domId === d.id).sort((a, b) => {
    if (a.aktivni !== false && b.aktivni === false) return -1
    if (a.aktivni === false && b.aktivni !== false) return 1
    return (a.jmeno || '\uffff').localeCompare(b.jmeno || '\uffff', 'cs')
  })
  const aktCount = akt.filter(o => o.aktivni !== false)
  const volCount = aktCount.filter(jeVolic)
  const hlasCount = aktCount.filter(o => jeVolic(o) && o.hlas)
  const units = [...new Set(akt.map(o => o.jednotka).filter(Boolean))].sort()

  function updateDum(field, value) {
    const updated = { ...d, [field]: value }
    useStore.setState(s => ({ domy: s.domy.map(x => x.id === d.id ? updated : x) }))
    saveDum(updated)
  }

  async function addPerson() {
    const o = {
      id: crypto.randomUUID(), domId: d.id, jmeno: '', rok: '', tel: '', email: '',
      pobyt: true, hlas: false, skupinaId: '', jednotka: '', aktivni: true,
      datum_od: '', datum_do: '', pozn: '',
    }
    useStore.setState(s => ({ osoby: [...s.osoby, o] }))
    await saveOsoba(o)
  }

  function updateOsoba(id, field, value) {
    const updated = osoby.map(o => o.id === id ? { ...o, [field]: value } : o)
    useStore.setState({ osoby: updated })
    const o = updated.find(x => x.id === id)
    if (o) saveOsoba(o)
  }

  async function removePerson(id) {
    await deleteOsoba(id)
  }

  async function handleDelete() {
    if (!confirm('Smazat dům i všechny osoby?')) return
    await deleteDum(d.id)
    closeEditor()
  }

  return (
    <div className="flex flex-col h-full">
      {/* Head */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-line">
        <div>
          <div className="text-xl font-bold">č.p. {d.cp || '(nový)'}</div>
          <div className="text-xs text-dim">
            {aktCount.length} osob · {volCount.length} voličů{hlasCount.length ? ` · ${hlasCount.length} hlasů` : ''}
          </div>
        </div>
        <div className="flex-1" />
        <button onClick={closeEditor} className="p-2 text-dim hover:text-ink">✕</button>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
        <Field label="Číslo popisné" value={d.cp} onChange={v => updateDum('cp', v)} />
        <Field label="Parcelní číslo" value={d.parcela} onChange={v => updateDum('parcela', v)} placeholder="245/3" />

        {/* Štítek chips */}
        <div>
          <div className="text-[10px] text-faint uppercase tracking-wider mb-1.5">Barva / štítek</div>
          <div className="flex flex-wrap gap-1.5">
            {stitky.map(s => (
              <button key={s.id} onClick={() => updateDum('stitekId', d.stitekId === s.id ? '' : s.id)}
                className={`flex items-center gap-1.5 px-2 py-1 rounded-full border text-xs ${d.stitekId === s.id ? 'border-ink bg-panel2' : 'border-line2 text-dim'}`}>
                <span className="w-2.5 h-2.5 rounded-full" style={{ background: s.color }} />
                {s.name}
              </button>
            ))}
          </div>
        </div>

        <Field label="Poznámka" value={d.pozn} onChange={v => updateDum('pozn', v)} multiline />

        {/* People */}
        <div className="pt-2 border-t border-line">
          <h3 className="text-[11px] uppercase tracking-widest text-dim font-semibold mb-2">
            Osoby · {aktCount.length} aktivních, {akt.length - aktCount.length} historických
          </h3>

          {akt.map(o => (
            <PersonCard key={o.id} o={o} units={units} skupiny={skupiny} isAdmin={isAdmin()}
              onUpdate={(f, v) => updateOsoba(o.id, f, v)}
              onDelete={() => removePerson(o.id)} />
          ))}

          <button onClick={addPerson}
            className="w-full py-2 border border-line2 border-dashed rounded-lg text-xs text-dim mt-1">
            + Přidat osobu
          </button>
        </div>
      </div>

      {/* Footer */}
      <div className="flex gap-2 px-4 py-3 border-t border-line">
        {isAdmin() && (
          <button onClick={handleDelete} className="text-xs text-red-300 border border-red-900/40 px-3 py-1.5 rounded-md mr-auto">
            Smazat dům
          </button>
        )}
        <button onClick={closeEditor}
          className="ml-auto px-4 py-2 bg-ink text-bg font-semibold rounded-lg text-sm">
          Hotovo
        </button>
      </div>
    </div>
  )
}

function PersonCard({ o, units, skupiny, isAdmin, onUpdate, onDelete }) {
  const v = jeVolic(o), bud = jeBudouci(o), ag = vek(o.rok), gone = o.aktivni === false

  return (
    <div className={`border rounded-lg p-2.5 mb-2 bg-panel2 ${gone ? 'border-dashed border-line opacity-55' : 'border-line'}`}>
      <div className="flex items-center gap-1.5 mb-1.5">
        <input value={o.jmeno} onChange={e => onUpdate('jmeno', e.target.value)}
          placeholder="Příjmení a jméno" className="flex-1 min-w-0 px-2 py-1 bg-bg border border-line2 rounded text-xs" />
        <input value={o.rok} onChange={e => onUpdate('rok', e.target.value)}
          placeholder="rok" inputMode="numeric" maxLength={4}
          className="w-16 px-2 py-1 bg-bg border border-line2 rounded text-xs text-center tabular-nums" />
        <button onClick={onDelete} className="px-1.5 text-dim hover:text-red-300 text-xs">✕</button>
      </div>

      <div className="flex flex-wrap gap-1 mb-1.5">
        {ag != null && <Pill>{ag} let</Pill>}
        <Pill color={v ? 'green' : undefined}>{gone ? 'odstěhoval/a se' : (v ? 'volič' : (bud ? '' : 'nevolič'))}</Pill>
        {bud && <Pill color="purple">brzy 18</Pill>}
      </div>

      <div className="grid grid-cols-2 gap-1.5 mb-1.5">
        {isAdmin ? (
          <>
            <input value={o.tel} onChange={e => onUpdate('tel', e.target.value)}
              placeholder="Telefon" inputMode="tel" className="px-2 py-1 bg-bg border border-line2 rounded text-xs" />
            <input value={o.email} onChange={e => onUpdate('email', e.target.value)}
              placeholder="E-mail" inputMode="email" className="px-2 py-1 bg-bg border border-line2 rounded text-xs" />
          </>
        ) : (
          <>
            <div className="px-2 py-1 text-xs text-faint">{o.tel ? '*** kontakt ***' : '–'}</div>
            <div className="px-2 py-1 text-xs text-faint">{o.email ? '*** kontakt ***' : '–'}</div>
          </>
        )}
      </div>

      <div className="grid grid-cols-2 gap-1.5 mb-1.5">
        <input value={o.jednotka} onChange={e => onUpdate('jednotka', e.target.value)}
          placeholder={`Byt. jednotka${units.length ? ' (' + units.join(', ') + ')' : ''}`}
          className="px-2 py-1 bg-bg border border-line2 rounded text-xs" />
        <input value={o.datum_od} onChange={e => onUpdate('datum_od', e.target.value)}
          placeholder="Bydlí od" className="px-2 py-1 bg-bg border border-line2 rounded text-xs" />
      </div>

      <div className="flex items-center gap-4 mb-1.5 text-xs">
        <label className="flex items-center gap-1.5 text-dim cursor-pointer">
          <input type="checkbox" checked={o.pobyt} onChange={e => onUpdate('pobyt', e.target.checked)} className="w-3.5 h-3.5" />
          trv. pobyt
        </label>
        {isAdmin && (
          <label className="flex items-center gap-1.5 text-dim cursor-pointer">
            <input type="checkbox" checked={o.hlas} onChange={e => onUpdate('hlas', e.target.checked)} className="w-3.5 h-3.5" />
            dá mi hlas
          </label>
        )}
        <label className="flex items-center gap-1.5 text-dim cursor-pointer">
          <input type="checkbox" checked={o.aktivni !== false} onChange={e => onUpdate('aktivni', e.target.checked)} className="w-3.5 h-3.5" />
          aktivní
        </label>
      </div>

      {gone && (
        <input value={o.datum_do} onChange={e => onUpdate('datum_do', e.target.value)}
          placeholder="Odstěhoval/a se (měsíc/rok)" className="w-full px-2 py-1 bg-bg border border-line2 rounded text-xs mb-1.5" />
      )}

      <select value={o.skupinaId} onChange={e => onUpdate('skupinaId', e.target.value)}
        className="w-full px-2 py-1 bg-bg border border-line2 rounded text-xs mb-1.5">
        <option value="">— bez skupiny —</option>
        {skupiny.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
      </select>

      <input value={o.pozn} onChange={e => onUpdate('pozn', e.target.value)}
        placeholder="Poznámka" className="w-full px-2 py-1 bg-bg border border-line2 rounded text-xs" />
    </div>
  )
}

function Field({ label, value, onChange, placeholder, multiline }) {
  const cls = "w-full px-2 py-1.5 bg-bg border border-line2 rounded text-xs text-ink"
  return (
    <div>
      <div className="text-[10px] text-faint uppercase tracking-wider mb-1">{label}</div>
      {multiline
        ? <textarea value={value || ''} onChange={e => onChange(e.target.value)} rows={2} placeholder={placeholder} className={cls} />
        : <input value={value || ''} onChange={e => onChange(e.target.value)} placeholder={placeholder} className={cls} />}
    </div>
  )
}

function Pill({ children, color }) {
  const colors = {
    green: 'text-green-200 border-green-800/50 bg-green-950/50',
    purple: 'text-purple-200 border-purple-800/50 bg-purple-950/50',
  }
  return (
    <span className={`text-[10px] px-1.5 py-0.5 rounded-full border ${colors[color] || 'border-line2 text-dim'}`}>
      {children}
    </span>
  )
}
