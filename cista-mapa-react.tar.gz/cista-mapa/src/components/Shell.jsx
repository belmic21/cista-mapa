import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useStore } from '../lib/store'
import MapView from './MapView'
import Sidebar from './Sidebar'
import Editor from './Editor'
import SearchBar from './SearchBar'

export default function Shell() {
  const { loadAll, loading, isAdmin, editorOpen } = useStore()
  const [sideOpen, setSideOpen] = useState(false)
  const [status, setStatus] = useState('Načítám…')

  useEffect(() => {
    loadAll().then(ok => setStatus(ok ? 'Online' : 'Chyba připojení'))
  }, [])

  return (
    <div className="h-screen flex flex-col bg-bg">
      {/* Top bar */}
      <div className="h-[52px] flex items-center gap-2 px-3 border-b border-line bg-panel z-50 shrink-0">
        <button onClick={() => setSideOpen(!sideOpen)} className="md:hidden p-2 text-ink">☰</button>
        <div className="font-bold whitespace-nowrap">
          Čistá
          <span className="block text-[11px] font-medium text-faint -mt-0.5">kontakty · voliči · vrstvy</span>
        </div>

        <SearchBar />

        <button onClick={() => useStore.getState().closeEditor()} className="md:hidden p-2 text-dim"
          style={{ display: editorOpen ? 'block' : 'none' }}>✕</button>

        {isAdmin() && (
          <button onClick={async () => { await supabase.auth.signOut(); location.reload() }}
            className="p-2 text-dim hover:text-ink" title="Odhlásit">⏻</button>
        )}
      </div>

      {/* Main area */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Sidebar */}
        <div className={`
          w-[312px] border-r border-line bg-panel overflow-y-auto shrink-0 z-30
          max-md:absolute max-md:inset-y-0 max-md:left-0 max-md:shadow-2xl
          max-md:transition-transform max-md:duration-200
          ${sideOpen ? 'max-md:translate-x-0' : 'max-md:-translate-x-full'}
        `}>
          <Sidebar status={status} onClose={() => setSideOpen(false)} />
        </div>

        {/* Map */}
        <div className="flex-1 relative">
          <MapView />
        </div>

        {/* Editor */}
        {editorOpen && (
          <div className="absolute top-0 right-0 bottom-0 w-[380px] max-w-[96vw] bg-panel border-l border-line shadow-2xl z-40
            max-md:w-full">
            <Editor />
          </div>
        )}
      </div>
    </div>
  )
}
