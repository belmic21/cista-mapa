import { useState } from 'react'
import { supabase } from '../lib/supabase'

export default function Login() {
  const [email, setEmail] = useState('')
  const [pass, setPass] = useState('')
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)

  async function login(e) {
    e.preventDefault()
    if (!email || !pass) return setErr('Vyplň e-mail a heslo.')
    setBusy(true); setErr('')
    const { error } = await supabase.auth.signInWithPassword({ email, password: pass })
    setBusy(false)
    if (error) setErr(error.message === 'Invalid login credentials' ? 'Špatný e-mail nebo heslo' : error.message)
  }

  return (
    <div className="h-screen flex items-center justify-center bg-bg p-5">
      <form onSubmit={login} className="w-full max-w-xs bg-panel border border-line rounded-xl p-7 text-center">
        <h1 className="text-2xl font-bold mb-1">📍 Čistá</h1>
        <p className="text-dim text-sm mb-6">Mapa kontaktů a voličů</p>
        <input type="email" value={email} onChange={e => setEmail(e.target.value)}
          placeholder="E-mail" autoComplete="email" inputMode="email"
          className="w-full mb-3 px-3 py-2.5 bg-panel2 border border-line2 rounded-lg text-ink" />
        <input type="password" value={pass} onChange={e => setPass(e.target.value)}
          placeholder="Heslo" autoComplete="current-password"
          className="w-full mb-4 px-3 py-2.5 bg-panel2 border border-line2 rounded-lg text-ink" />
        <button type="submit" disabled={busy}
          className="w-full py-3 bg-ink text-bg font-semibold rounded-lg hover:bg-white disabled:opacity-50">
          {busy ? 'Přihlašuji…' : 'Přihlásit se'}
        </button>
        {err && <p className="text-red-400 text-sm mt-3">{err}</p>}
      </form>
    </div>
  )
}
